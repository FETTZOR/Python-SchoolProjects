#! /usr/bin/python3

# temp text upd nnew
import smtplib
from email.message import EmailMessage
import mimetypes


def email_sender(subject, body):
    gmail_user = "hhttajapai@gmail.com"

    # with open("/home/fetqq/python_course_2021/JupyterLabSchoolProjects/email_sender/pw.txt") as filereader:
    gmail_password = "Breathe1337!"
    where_you_want_to_get_info = input("Please write email where you want to get information: ")
    to = [where_you_want_to_get_info]
    # subject = 'very important message'
    # body = 'https://youtu.be/dQw4w9WgXcQ'

    msg = EmailMessage()
    msg.set_content(body)
    msg['Subject'] = subject
    msg['from'] = gmail_user
    msg['To'] = to
    mime_type, _ = mimetypes.guess_type('game_information.csv')
    mime_type, _ = mimetypes.guess_type('game.py')
    mime_type, mime_subtype = mime_type.split('/')

    with open('game_information.csv', 'rb') as file:
        msg.add_attachment(file.read(),
                           maintype=mime_type,
                           subtype=mime_subtype,
                           filename='game_information.csv')


    print(msg)
    while True:
        try:
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.ehlo()
            server.starttls()
            server.ehlo()
        except:
            print('cannot connect to server')
            break
        try:
            server.login(gmail_user, gmail_password)
        except:
            print("error with username or pw")
            break
        try:
            server.send_message(msg)
        except:
            print("error with senging email")
            break
        try:
            server.close()
        except:
            print("error with server closing")
            break
        break
